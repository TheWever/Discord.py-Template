import asyncio
from PIL import ImageColor
import os
from discord.ext import commands
import aiohttp
from discord import Member, Webhook, AsyncWebhookAdapter
import discord
import random
import traceback
from datetime import datetime
import sys
bot = discord.Client()
bot = commands.Bot(command_prefix='!', help_command=None, intents=discord.Intents().all())
with open('Token', 'r') as f:
    token = f.read()

@bot.event
async def on_ready():
    bot.loop.create_task(status_task())
    print('... Bot is online!')

async def del_message(message):
    try:
        await message.delete()
    except:
        pass

async def status_task():
    while True:
        await bot.change_presence(
            status=discord.Status.online,
            activity=discord.Game(f'Pefix: "!" | Made by Wever#5665'))

@bot.command()
async def say(ctx, *, arg):
    await del_message(ctx.message)
    await ctx.send(arg)

class NewHelpCommand(commands.MinimalHelpCommand):
    async def send_pages(self):
        destination = self.context.author
        embed = discord.Embed(
            title="**Name**",
            description="**Prefix:  | Commands:**",
            color=discord.Color.blue()
        )
        embed.add_field(name='say {text}:', value='Will repeat your text!')
        await destination.send(embed=embed)
bot.help_command = NewHelpCommand()

@bot.event
async def on_message(message):
    global MESSAGE
    MESSAGE = message
    await bot.process_commands(message)

bot.run(token)